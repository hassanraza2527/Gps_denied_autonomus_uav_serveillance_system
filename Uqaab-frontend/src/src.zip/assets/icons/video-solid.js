import React from 'react';
import Svg, { Path } from 'react-native-svg';

const VideoSolidIcon = ({ width = 24, height = 24, color = "#666" }) => (
  <Svg width={width} height={height} viewBox="0 0 24 24" fill={color}>
    <Path d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z" />
  </Svg>
);

export default VideoSolidIcon;